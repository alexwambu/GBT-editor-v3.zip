# GBT-editor

A cloud-based ML code editor that trains classification models and auto-deploys via Streamlit.

## How to Run

1. Install requirements:
```
pip install -r requirements.txt
```

2. Run the app:
```
streamlit run app.py
```

3. Train models, export `.pkl` files, and download trained models.

## Deployment (Auto)

Push to GitHub + connect to Streamlit sharing or Render:
- Streamlit: https://streamlit.io/cloud
- Render: auto-detects `app.py`

Make sure `app.py` is root-level in the repo.