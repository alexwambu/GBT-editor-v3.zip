import streamlit as st
import pandas as pd
import joblib
import os
import json
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.svm import SVC, SVR
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from datetime import datetime

st.set_page_config(page_title="GBT-editor ML IDE+", layout="centered")
st.title("GBT-editor: Train, Upload & Manage ML Models")

MODELS_DB = "models.json"

def save_model_entry(name, model_path, model_type):
    if os.path.exists(MODELS_DB):
        with open(MODELS_DB, "r") as f:
            db = json.load(f)
    else:
        db = {}
    version = datetime.now().strftime("%Y%m%d%H%M%S")
    db[name] = {"path": model_path, "type": model_type, "version": version}
    with open(MODELS_DB, "w") as f:
        json.dump(db, f)

def load_models_list():
    if os.path.exists(MODELS_DB):
        with open(MODELS_DB, "r") as f:
            return json.load(f)
    return {}

menu = st.sidebar.selectbox("Menu", ["Train Model", "Upload & Test Model", "Saved Models"])

if menu == "Train Model":
    st.subheader("1. Load Dataset")
    dataset_option = st.selectbox("Choose dataset", ["Iris (classification)", "Boston (regression)", "Upload CSV"])
    if dataset_option == "Iris (classification)":
        from sklearn.datasets import load_iris
        data = load_iris(as_frame=True)
        df = data.frame
        problem_type = "classification"
    elif dataset_option == "Boston (regression)":
        from sklearn.datasets import load_diabetes
        data = load_diabetes(as_frame=True)
        df = data.frame
        problem_type = "regression"
    else:
        uploaded_file = st.file_uploader("Upload your CSV")
        if uploaded_file:
            df = pd.read_csv(uploaded_file)
            problem_type = st.radio("What type of problem is this?", ["classification", "regression"])
        else:
            st.stop()

    st.write(df.head())
    target = st.selectbox("Select target column", df.columns)
    features = df.drop(columns=[target])
    labels = df[target]

    st.subheader("2. Select Model")
    if problem_type == "classification":
        model_type = st.selectbox("Choose ML Model", ["RandomForest", "LogisticRegression", "SVC"])
        if model_type == "RandomForest":
            model = RandomForestClassifier()
        elif model_type == "LogisticRegression":
            model = LogisticRegression(max_iter=1000)
        else:
            model = SVC(probability=True)
    else:
        model_type = st.selectbox("Choose ML Model", ["RandomForestRegressor", "LinearRegression", "SVR"])
        if model_type == "RandomForestRegressor":
            model = RandomForestRegressor()
        elif model_type == "LinearRegression":
            model = LinearRegression()
        else:
            model = SVR()

    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    st.success("Model trained!")

    if problem_type == "classification":
        preds = model.predict(X_test)
        st.text("Classification Report:")
        st.text(classification_report(y_test, preds))

        cm = confusion_matrix(y_test, preds)
        fig, ax = plt.subplots()
        sns.heatmap(cm, annot=True, fmt='d', ax=ax, cmap='Blues')
        ax.set_title("Confusion Matrix")
        st.pyplot(fig)
    else:
        preds = model.predict(X_test)
        mse = mean_squared_error(y_test, preds)
        r2 = r2_score(y_test, preds)
        st.write(f"Mean Squared Error: {mse:.2f}")
        st.write(f"R² Score: {r2:.2f}")

        fig, ax = plt.subplots()
        ax.scatter(y_test, preds, alpha=0.6)
        ax.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
        ax.set_xlabel("Actual")
        ax.set_ylabel("Predicted")
        ax.set_title("Prediction vs Actual")
        st.pyplot(fig)

    model_name = st.text_input("Enter model name to save")
    if st.button("Save Model"):
        path = f"{model_name}.pkl"
        joblib.dump(model, path)
        save_model_entry(model_name, path, problem_type)
        st.success(f"Model saved as {path}")

elif menu == "Upload & Test Model":
    st.subheader("Upload Pretrained Model and Test")
    model_file = st.file_uploader("Upload .pkl Model", type=["pkl"])
    test_file = st.file_uploader("Upload Test CSV")

    if model_file and test_file:
        model = joblib.load(model_file)
        df = pd.read_csv(test_file)
        st.write(df.head())
        target = st.selectbox("Target column in test set", df.columns)
        X = df.drop(columns=[target])
        y = df[target]
        try:
            preds = model.predict(X)
            st.text("Classification Report:")
            st.text(classification_report(y, preds))
        except:
            preds = model.predict(X)
            st.write(f"Mean Squared Error: {mean_squared_error(y, preds):.2f}")
            st.write(f"R² Score: {r2_score(y, preds):.2f}")

elif menu == "Saved Models":
    st.subheader("Saved Models Database")
    db = load_models_list()
    if not db:
        st.info("No saved models yet.")
    else:
        for name, meta in db.items():
            st.markdown(f"**{name}** - `{meta['path']}` (Type: {meta['type']}, Version: {meta['version']})")
            with open(meta["path"], "rb") as f:
                st.download_button(label=f"Download {name}", data=f, file_name=meta["path"])